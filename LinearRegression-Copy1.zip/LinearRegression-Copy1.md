# Discovery and Learning with Big Data/Machine Learning
### Austin Glenn
### Machine Learning Supervised Linear Regression

### Supervised Learning Workflow

![supervised%20learning%20workflow.png](attachment:supervised%20learning%20workflow.png)
- You can see in this picture that supervised learning startw with the data set.  Remember since it is supervised, the data is labeled.  Then there is some data preprocessing (cleaning) to be done.  Next, you will declare your input (X/Indepentdent variables) and output (Target Variable/Dependent or Y) NumPy Arrays.  Then the data is split into a testing and training set.  Then you will build and train the model, use the model for predictions, and lastly, evaluate/validate the model.  So let's begin.

## <span style= 'color: red'>1. What is happening in the code block below? Enter your answer by adding a new code block and use markdown.</span>

Importing pandas library as standard 'pd'
Importing numpy library as standard 'np'
Importing the necessary librarys to perform certain functions 

## <span style= 'color: red'>2. What is the Pandas libarary used for?  Enter your answer by adding a new code block and use markdown.</span> 

Pandas library is used for data manipulation and anlaysis 

##  <span style= 'color: red'>3. What is the Matplotlib library used for?  Enter your answer by adding a new code block and use markdown.</span>

Matplotlib is used as a plotting tool using object oriented API for graphical representations 

## <span style= 'color: red'>4. What is the Seaborn library used for?  Enter your answer by adding a new code block and use markdown.</span>

Seaborn library is used for visualzation from the data built on the matplotlib functionality


```python
import pandas as pd
import numpy as np
from pandas.plotting import scatter_matrix
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
import seaborn as sns
import matplotlib.pyplot as plt
```

### Description of Boston Housing Dataset ['https://www.kaggle.com/c/boston-housing']

- CRIM: This is the per capita crime rate by town
- ZN: This is the proportion of residential land zoned for lots larger than 25,000 sq.ft.
- INDUS: This is the proportion of non-retail business acres per town.
- CHAS: This is the Charles River dummy variable (this is equal to 1 if tract bounds river; 0 otherwise)
- NOX: This is the nitric oxides concentration (parts per 10 million)
- RM: This is the average number of rooms per dwelling
- AGE: This is the proportion of owner-occupied units built prior to 1940
- DIS: This is the weighted distances to five Boston employment centers
- RAD: This is the index of accessibility to radial highways
- TAX: This is the full-value property-tax rate per 10,000 dollars
- PTRATIO: This is the pupil-teacher ratio by town
- AA: This is calculated as 1000(AA — 0.63)², where AA is the proportion of people of African American descent by town
- LSTAT: This is the percentage lower status of the population
- MEDV: This is the median value of owner-occupied homes in $1000s

##  <span style= 'color: red'>5. What is happening in the code block below question 6? Enter your answer by adding a new code block and use markdown.</span>

The dataset 'housing_boston.csv' is being loaded into a variable called housingfile

##  <span style= 'color: red'>6. What is the dataset that is loading?  Enter your answer by adding a new code block and use markdown.</span>

A csv file called 'housing_boston.csv' that contains information regarding crime rate by town / rooms per dwelling / accessibility to radial highways etc... 


```python
# Specify location of the dataset.  
housingfile = 'housing_boston.csv'
```


```python
# Load the data into a Pandas DataFrame
df= pd.read_csv (housingfile, header=None)
```

## <span style= 'color: red'>7. What is the df.head() used for?  Enter your answer by adding a new code block and use markdown.</span>

df.head() is a common funtion that returns the first 5 rows 


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>10</th>
      <th>11</th>
      <th>12</th>
      <th>13</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>0</td>
      <td>0.538</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1</td>
      <td>296</td>
      <td>15.3</td>
      <td>396.90</td>
      <td>4.98</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>396.90</td>
      <td>9.14</td>
      <td>21.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>392.83</td>
      <td>4.03</td>
      <td>34.7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>394.63</td>
      <td>2.94</td>
      <td>33.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>396.90</td>
      <td>5.33</td>
      <td>36.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Give names to the columns since there are no headers.
col_names = ['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX','RM', 'AGE', 'DIS', 'RAD', 'TAX', 'PTRATIO', 'AA', 'LSTAT', 'MEDV']
```

## <span style= 'color: red'>8. What is happening in the code block below?  Enter your answer by adding a new code block and use markdown.</span>

the variable col_names which is an array of strings intended to be column headersz are equal to the function df.columns command


```python
df.columns = col_names
```

## <span style= 'color: red'>9. What happens when the head () function is called?</span>

Now the first 5 rows are going to be different... the 1st row is now the column header defined by df.columns command


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>AA</th>
      <th>LSTAT</th>
      <th>MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>0</td>
      <td>0.538</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1</td>
      <td>296</td>
      <td>15.3</td>
      <td>396.90</td>
      <td>4.98</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>396.90</td>
      <td>9.14</td>
      <td>21.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>392.83</td>
      <td>4.03</td>
      <td>34.7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>394.63</td>
      <td>2.94</td>
      <td>33.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>396.90</td>
      <td>5.33</td>
      <td>36.2</td>
    </tr>
  </tbody>
</table>
</div>



## Preprocess the Dataset

## <span style= 'color: red'>10. What is happening in the code block below?  Enter your answer by adding a new code block and use markdown.</span>

the df.issnull().sum() function returns the number of missing values in the dataset


```python
df.isnull().sum()
```




    CRIM       0
    ZN         0
    INDUS      0
    CHAS       0
    NOX        0
    RM         0
    AGE        0
    DIS        0
    RAD        0
    TAX        0
    PTRATIO    0
    AA         0
    LSTAT      0
    MEDV       0
    dtype: int64



## Performing the Exploratory Data Analysis (EDA)

## <span style= 'color:red'> 11.  What happens when the df.shape function is called? Enter your answer by adding a new code block and use markdown. </span>

this command shows us the architecture of the matrix... in this case it is number of rows: 452, columns: 14 


```python
print(df.shape)
```

    (452, 14)


## <span style= 'color:red'> 12.  What happens when the df.dtypes function is called?  Enter your answer by adding a new code block and use markdown. </span>

this command shows us the data types of the columns 


```python
print(df.dtypes)
```

    CRIM       float64
    ZN         float64
    INDUS      float64
    CHAS         int64
    NOX        float64
    RM         float64
    AGE        float64
    DIS        float64
    RAD          int64
    TAX          int64
    PTRATIO    float64
    AA         float64
    LSTAT      float64
    MEDV       float64
    dtype: object


## <span style= 'color:red'> 13.  What happens when the df.describe () is called?  Enter your answer by adding a new code block and use markdown. </span>

this command gives us a set of statistiscal parameters contained in each column 


```python
print(df.describe())
```

                 CRIM          ZN       INDUS        CHAS         NOX          RM  \
    count  452.000000  452.000000  452.000000  452.000000  452.000000  452.000000   
    mean     1.420825   12.721239   10.304889    0.077434    0.540816    6.343538   
    std      2.495894   24.326032    6.797103    0.267574    0.113816    0.666808   
    min      0.006320    0.000000    0.460000    0.000000    0.385000    3.561000   
    25%      0.069875    0.000000    4.930000    0.000000    0.447000    5.926750   
    50%      0.191030    0.000000    8.140000    0.000000    0.519000    6.229000   
    75%      1.211460   20.000000   18.100000    0.000000    0.605000    6.635000   
    max      9.966540  100.000000   27.740000    1.000000    0.871000    8.780000   
    
                  AGE         DIS         RAD         TAX     PTRATIO          AA  \
    count  452.000000  452.000000  452.000000  452.000000  452.000000  452.000000   
    mean    65.557965    4.043570    7.823009  377.442478   18.247124  369.826504   
    std     28.127025    2.090492    7.543494  151.327573    2.200064   68.554439   
    min      2.900000    1.129600    1.000000  187.000000   12.600000    0.320000   
    25%     40.950000    2.354750    4.000000  276.750000   16.800000  377.717500   
    50%     71.800000    3.550400    5.000000  307.000000   18.600000  392.080000   
    75%     91.625000    5.401100    7.000000  411.000000   20.200000  396.157500   
    max    100.000000   12.126500   24.000000  711.000000   22.000000  396.900000   
    
                LSTAT        MEDV  
    count  452.000000  452.000000  
    mean    11.441881   23.750442  
    std      6.156437    8.808602  
    min      1.730000    6.300000  
    25%      6.587500   18.500000  
    50%     10.250000   21.950000  
    75%     15.105000   26.600000  
    max     34.410000   50.000000  


## <span style= 'color:red'> 14.  What happens when the df.hist function is called?  Enter your answer by adding a new code block and use markdown. </span>

this function creates a histogram for the data frame 


```python
# I encourage you to change some of the parameters. 
#Remember what you did in the previous homework.
df.hist(edgecolor= 'black', color= 'maroon', figsize=(14,12), bins= 10)
plt.show()
```


![png](output_45_0.png)


## <span style= 'color:red'> 15. Create a new code block below and change the bins to 15 and the figsize to 18 x 18. Be sure to run the code.  </span>


```python
df.hist(edgecolor= 'black', color= 'maroon', figsize=(18,18), bins= 15)
plt.show()
```


![png](output_47_0.png)


## <span style= 'color:red'> 16. What happens when the df.plot function is called?  Enter your answer by adding a new code block and use markdown. </span>

we get a simliar representation of the data, but df.plot is a smoother visualization that does not involve grids like the histogram, but rather a smoother sleaker line graph 


```python
# Notes:  14 numeric variable, at least 14 plots, layout (5,3): 5 rows, each row with 3 plots
df.plot(kind='density', subplots=True, layout= (5,3), sharex=False, legend=True, fontsize=1, figsize= (12,16))
plt.show()
```


![png](output_50_0.png)


### Creating a Box Plot


```python
# Boxplots
df.plot(kind="box", subplots=True, layout=(5,3), sharex=False, figsize=(20,18))
plt.show()
```


![png](output_52_0.png)


## <span style= 'color:red'> 17. Create a new code block below and change the boxpot layout to 2,7 and the figsize to 22 x 22. Be sure to run the code.  </span>


```python
df.plot(kind="box", subplots=True, layout=(2,7), sharex=False, figsize=(22,22))
plt.show()
```


![png](output_54_0.png)


## Correlation Analysis and Feature Selection

## Correlations


```python
# We will decrease the number of decimal places with the format function
pd.options.display.float_format = '{:,.3f}'.format
```


```python
# Here we will get the correlations, with only 3 decimals.
df.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>AA</th>
      <th>LSTAT</th>
      <th>MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>CRIM</th>
      <td>1.000</td>
      <td>-0.281</td>
      <td>0.574</td>
      <td>0.050</td>
      <td>0.637</td>
      <td>-0.142</td>
      <td>0.448</td>
      <td>-0.462</td>
      <td>0.898</td>
      <td>0.826</td>
      <td>0.319</td>
      <td>-0.413</td>
      <td>0.425</td>
      <td>-0.286</td>
    </tr>
    <tr>
      <th>ZN</th>
      <td>-0.281</td>
      <td>1.000</td>
      <td>-0.514</td>
      <td>-0.060</td>
      <td>-0.501</td>
      <td>0.307</td>
      <td>-0.556</td>
      <td>0.656</td>
      <td>-0.267</td>
      <td>-0.269</td>
      <td>-0.364</td>
      <td>0.150</td>
      <td>-0.411</td>
      <td>0.332</td>
    </tr>
    <tr>
      <th>INDUS</th>
      <td>0.574</td>
      <td>-0.514</td>
      <td>1.000</td>
      <td>0.103</td>
      <td>0.739</td>
      <td>-0.365</td>
      <td>0.606</td>
      <td>-0.669</td>
      <td>0.513</td>
      <td>0.673</td>
      <td>0.317</td>
      <td>-0.317</td>
      <td>0.565</td>
      <td>-0.412</td>
    </tr>
    <tr>
      <th>CHAS</th>
      <td>0.050</td>
      <td>-0.060</td>
      <td>0.103</td>
      <td>1.000</td>
      <td>0.134</td>
      <td>0.077</td>
      <td>0.123</td>
      <td>-0.141</td>
      <td>0.057</td>
      <td>0.017</td>
      <td>-0.100</td>
      <td>0.013</td>
      <td>-0.009</td>
      <td>0.154</td>
    </tr>
    <tr>
      <th>NOX</th>
      <td>0.637</td>
      <td>-0.501</td>
      <td>0.739</td>
      <td>0.134</td>
      <td>1.000</td>
      <td>-0.265</td>
      <td>0.707</td>
      <td>-0.746</td>
      <td>0.542</td>
      <td>0.615</td>
      <td>0.103</td>
      <td>-0.358</td>
      <td>0.537</td>
      <td>-0.333</td>
    </tr>
    <tr>
      <th>RM</th>
      <td>-0.142</td>
      <td>0.307</td>
      <td>-0.365</td>
      <td>0.077</td>
      <td>-0.265</td>
      <td>1.000</td>
      <td>-0.188</td>
      <td>0.139</td>
      <td>-0.096</td>
      <td>-0.215</td>
      <td>-0.334</td>
      <td>0.108</td>
      <td>-0.607</td>
      <td>0.740</td>
    </tr>
    <tr>
      <th>AGE</th>
      <td>0.448</td>
      <td>-0.556</td>
      <td>0.606</td>
      <td>0.123</td>
      <td>0.707</td>
      <td>-0.188</td>
      <td>1.000</td>
      <td>-0.720</td>
      <td>0.359</td>
      <td>0.427</td>
      <td>0.193</td>
      <td>-0.224</td>
      <td>0.573</td>
      <td>-0.300</td>
    </tr>
    <tr>
      <th>DIS</th>
      <td>-0.462</td>
      <td>0.656</td>
      <td>-0.669</td>
      <td>-0.141</td>
      <td>-0.746</td>
      <td>0.139</td>
      <td>-0.720</td>
      <td>1.000</td>
      <td>-0.388</td>
      <td>-0.444</td>
      <td>-0.152</td>
      <td>0.234</td>
      <td>-0.424</td>
      <td>0.139</td>
    </tr>
    <tr>
      <th>RAD</th>
      <td>0.898</td>
      <td>-0.267</td>
      <td>0.513</td>
      <td>0.057</td>
      <td>0.542</td>
      <td>-0.096</td>
      <td>0.359</td>
      <td>-0.388</td>
      <td>1.000</td>
      <td>0.873</td>
      <td>0.387</td>
      <td>-0.353</td>
      <td>0.310</td>
      <td>-0.218</td>
    </tr>
    <tr>
      <th>TAX</th>
      <td>0.826</td>
      <td>-0.269</td>
      <td>0.673</td>
      <td>0.017</td>
      <td>0.615</td>
      <td>-0.215</td>
      <td>0.427</td>
      <td>-0.444</td>
      <td>0.873</td>
      <td>1.000</td>
      <td>0.385</td>
      <td>-0.367</td>
      <td>0.411</td>
      <td>-0.346</td>
    </tr>
    <tr>
      <th>PTRATIO</th>
      <td>0.319</td>
      <td>-0.364</td>
      <td>0.317</td>
      <td>-0.100</td>
      <td>0.103</td>
      <td>-0.334</td>
      <td>0.193</td>
      <td>-0.152</td>
      <td>0.387</td>
      <td>0.385</td>
      <td>1.000</td>
      <td>-0.090</td>
      <td>0.303</td>
      <td>-0.461</td>
    </tr>
    <tr>
      <th>AA</th>
      <td>-0.413</td>
      <td>0.150</td>
      <td>-0.317</td>
      <td>0.013</td>
      <td>-0.358</td>
      <td>0.108</td>
      <td>-0.224</td>
      <td>0.234</td>
      <td>-0.353</td>
      <td>-0.367</td>
      <td>-0.090</td>
      <td>1.000</td>
      <td>-0.291</td>
      <td>0.265</td>
    </tr>
    <tr>
      <th>LSTAT</th>
      <td>0.425</td>
      <td>-0.411</td>
      <td>0.565</td>
      <td>-0.009</td>
      <td>0.537</td>
      <td>-0.607</td>
      <td>0.573</td>
      <td>-0.424</td>
      <td>0.310</td>
      <td>0.411</td>
      <td>0.303</td>
      <td>-0.291</td>
      <td>1.000</td>
      <td>-0.706</td>
    </tr>
    <tr>
      <th>MEDV</th>
      <td>-0.286</td>
      <td>0.332</td>
      <td>-0.412</td>
      <td>0.154</td>
      <td>-0.333</td>
      <td>0.740</td>
      <td>-0.300</td>
      <td>0.139</td>
      <td>-0.218</td>
      <td>-0.346</td>
      <td>-0.461</td>
      <td>0.265</td>
      <td>-0.706</td>
      <td>1.000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# We could simply look at the correlations but a heatmap is a great way to present to the general audience.
plt.figure(figsize =(16,10))
sns.heatmap(df.corr(), annot=True)
plt.show()
```


![png](output_59_0.png)


## <span style= 'color:red'> 18. What are the top three variables that impact the target variable (MEDV)?  Remember, the most impactful can be either a positive or a negative value.  Enter your answer by adding a new code block and use markdown.  </span>

RM, ZN, AA


```python
# Now let's say we want to decrease the amount of variables in our heatmap.  We would use the following code.  This will be on the final!
#  Remember how to make a subset.  Try using different variables.
df2= df[['CRIM','INDUS', 'TAX','MEDV']]
```

## <span style= 'color:red'> 19. What is happening with the code df2.corr ()?  Enter your answer by adding a new code block and use markdown. </span>

df2.corr() is a function that shows the correlation between variables in a matrix rather than the heatmap we just used


```python
df2.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>INDUS</th>
      <th>TAX</th>
      <th>MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>CRIM</th>
      <td>1.000</td>
      <td>0.574</td>
      <td>0.826</td>
      <td>-0.286</td>
    </tr>
    <tr>
      <th>INDUS</th>
      <td>0.574</td>
      <td>1.000</td>
      <td>0.673</td>
      <td>-0.412</td>
    </tr>
    <tr>
      <th>TAX</th>
      <td>0.826</td>
      <td>0.673</td>
      <td>1.000</td>
      <td>-0.346</td>
    </tr>
    <tr>
      <th>MEDV</th>
      <td>-0.286</td>
      <td>-0.412</td>
      <td>-0.346</td>
      <td>1.000</td>
    </tr>
  </tbody>
</table>
</div>



### Creating a Pair Plot


```python
# Let's illustrate the correlations using color.   
sns.pairplot(df,height=3, aspect= 1);

```


![png](output_67_0.png)



```python
# Let's try the pairplot with only the variables in df2
sns.pairplot(df2, height=5.5);
plt.show()
```


![png](output_68_0.png)


### Creating a Heat Map


```python
# Now we will make a heatmap with only the variables in df2 subset.  Again, it is very important to understand this for the final.plt.figure(figsize =(20,12))
plt.figure(figsize = (20,12))
sns.heatmap(df2.corr(), annot=True)
plt.show()
```


![png](output_70_0.png)



```python
#If you want to change the color and font, to make the labels easier to read, use this code.
plt.figure(figsize =(20,12))
sns.heatmap(df2.corr(), cmap="Blues", annot=True, annot_kws={"fontsize":20})
plt.show()
```


![png](output_71_0.png)


### Separate the Dataset into Input & Output NumPy Arrays


```python
#import train test split library
from sklearn.model_selection import train_test_split
```


```python
# Store the dataframe values into a numPy array
array = df2.values

# Separate the array into input and output components by slicing (you used this in your homework)
# For X (input) [:,3] --> All the rows and columns from 0 up to 3
X = array [:, 0:3]

# For Y (output) [:3] --> All the rows in the last column (MEDV)
Y = array [:,3]
```

## <span style= 'color:red'> 20. What would the X array be if we wanted to include all rows and wanted 5 variables instead of 3 (see above)?  Of course, this would be from the df not df2 since there are not 5 variable in the df2 dataframe.  Enter your answer by adding a new code block and use markdown.  </span>

X = array [:, 0:5]

### Spilt into Input/Output Array into Training/Testing Datasets


```python
# Split the dataset --> training sub-dataset:  80%, and test sub-dataset:  20%

# Selection of records to inclue in which sub-dataset must be done randomly - use the for seed radomization
seed = 7

# Split the dataset (both input & output) into training/testing datasets
X_train, X_test, Y_train, Y_test= train_test_split(X,Y, test_size=0.2, random_state=seed)
```

## <span style= 'color:red'> 21. In the above code, do you know what code tells the model that we want a test sub-dataset of 20%?  Enter your answer by adding a new code block and use markdown.  </span>

Y_test= train_test_split(X,Y, test_size=0.2, random_state=seed)

### Build and Train the Model

## <span style= 'color:red'> 22. From the code block below, what is the algorithm we are using for the model?  Enter your answer by adding a new code block and use markdown.  </span>

Linear Regression

## <span style= 'color:red'> 23. What does the intercept and coefficients tell us?  Enter your answer by adding a new code block and use markdown.  </span>

the expected mean of the value 


```python
# Build the model
model=LinearRegression()

# Train the model using the training sub-dataset
model.fit(X_train, Y_train)

#Print out the coefficients and the intercept
# Print intercept and coefficients

print ("Intercept:", model.intercept_)
print ("Coefficients:", model.coef_)
```

    Intercept: 31.393427670412926
    Coefficients: [ 0.09859287 -0.42388844 -0.00931847]



```python
# If we want to print out the list of the coefficients with their correspondent variable name
# Pair the feature names with the coefficients
names_2 = ["CRIM", "INDUS", "TAX"]

coeffs_zip = zip(names_2, model.coef_)

# Convert iterator into set
coeffs = set(coeffs_zip)

# Print (coeffs)
for coef in coeffs:
    print (coef, "\n")
```

    ('INDUS', -0.4238884417716133) 
    
    ('TAX', -0.009318474474503407) 
    
    ('CRIM', 0.0985928723914378) 
    



```python
LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)



### Calculate R-Squared


```python
R_squared = model.score(X_test, Y_test)
print("R-squared: ", R_squared)
```

    R-squared:  0.1547331337359037


### Notes: The higher the R-squared, the better (0 – 100%). Depending on the model, the best models score above 83%. The R-squared value tell us how good the independent variables predict the dependent variable.  This is very low.  Think about how you could increase the R-squared. What variables would you use?  This will be important for the final.

## Prediction


```python
# CRIM = 12
# INDUS = 10
# TAX = 450
model.predict([[12,10,450]])
```




    array([24.14434421])



## <span style= 'color:red'> 24. What is the predicted amount of the home with the variables and values you have entered above? Enter your answer by adding a new code block and use markdown. You can look up in the description for the dataset at the beginning of the assignment to refresh your memory, if needed.  </span>

$24,000


```python
# CRIM = 2
# INDUS = 30
# TAX = 50
model.predict([[2,30,50]])
```




    array([18.40803644])



## <span style= 'color:red'> 25. What is the predicted amount of the home with the variables and values you have entered above? Enter your answer by adding a new code block and use markdown. </span>

$18,000

## Evaluate/Validate Algorithm/Model, Using K-Fold Cross Validation


```python
# Evaluate the algorithm
# Specify the K-size
num_folds = 10
# Fix the random seed
# must use the same seed value so that the same subsets can be obtained
# for each time the process is repeated
seed = 7
# Split the whole data set into folds
kfold= KFold(n_splits=num_folds, random_state=seed, shuffle=True)
# For Linear regression, we can use MSE (mean squared error) value
# to evaluate the model/algorithm
scoring = 'neg_mean_squared_error'
# Train the model and run K-foLd cross-validation to validate/evaluate the model
results = cross_val_score(model, X, Y, cv=kfold, scoring=scoring)
# Print out the evaluation results
# Result: the average of all the results obtained from the k-fold cross validation
print("Average of all results from the K-fold Cross Validation, using negative mean squared error:",results.mean())
```

    Average of all results from the K-fold Cross Validation, using negative mean squared error: -64.35862748210982


### Notes: After we train, we evaluate. We are using K-fold to determine if the model is acceptable. We pass the whole set since the system will divide it for us. We see there is a -64 avg of all error (mean of square errors). This value would traditionally be a positive value but scikit reports this value as a negative value. If the square root would have been evaluated, the value would have been around 8.


```python
# Evaluate the algorithm
# Specify the K-size
num_folds = 10
# Fix the random seed must use the same seed value so that the same subsets can be obtained
# for each time the process is repeated
seed = 7
# Split the whole data set into folds
kfold= KFold(n_splits=num_folds, random_state=seed, shuffle=True)
# For Linear regression, we can use explained variance value to evaluate the model/algorithm
scoring = 'explained_variance'
# Train the model and run K-foLd cross-validation to validate/evaluate the model
results = cross_val_score(model, X, Y, cv=kfold, scoring=scoring)
# Print out the evaluation results
# Result: the average of all the results obtained from the k-fold cross validation
print("Average of all results from the K-fold Cross Validation, using exlpained variance:",results.mean())
```

    Average of all results from the K-fold Cross Validation, using exlpained variance: 0.19023822025958687


### In the above code we are using a different scoring parameter.  Here we use the Explained Varience.  Best possible score is 1.0, lower values are worse.

#### To learn more about Scikit Learning scoring [https://scikit-learn.org/stable/modules/model_evaluation.html]

## <span style= 'color:red'> 26. What are your thoughts on this process?  Do you have any quesitons? Enter your answer by adding a new code block and use markdown.  </span>

An interesting approach to learning the syntax and understand from a data science perspective 


```python

```
